<script setup${SCRIPT_LANG_ATTR}>

</script>

<template>
  #[[$END$]]#
</template>

<script ${SCRIPT_LANG_ATTR}>
	export default {
		name: "$NAME",
		props:{},
		computed: {},
		data() {
			return {}
		},
		mounted() {
		},
		methods: {},
	}

</script>

<style scoped${STYLE_LANG_ATTR}>

</style>